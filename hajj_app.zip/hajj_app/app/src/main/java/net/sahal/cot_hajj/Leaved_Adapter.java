package net.sahal.cot_hajj;


import android.content.Context;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class Leaved_Adapter extends RecyclerView.Adapter<Leaved_Adapter.MyViewHolder>{

    private List<Leaved_Buses> leavedList;
    private Context context;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView busesNo;

        Typeface type = Typeface.createFromAsset(itemView.getContext().getAssets(),"fonts/JF_Flat_regular.ttf");



        public MyViewHolder(View view) {
            super(view);

            busesNo = view.findViewById(R.id.adad);
            busesNo.setTypeface(type);

        }

    }

    public Leaved_Adapter(List<Leaved_Buses> leavedList, Context context) {
        this.leavedList = leavedList;
        this.context = context;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_leaved_bus_row, parent, false);


        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        Leaved_Buses bus = leavedList.get(position);

        holder.busesNo.setText(bus.getBus_number());

    }


    @Override
    public int getItemCount() {
        return leavedList.size();
    }

}