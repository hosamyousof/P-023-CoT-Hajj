package net.sahal.cot_hajj.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import net.sahal.cot_hajj.Bus_Adapter;
import net.sahal.cot_hajj.R;
import net.sahal.cot_hajj.dist_Adapter;


public class DistFragment extends Fragment {

    RecyclerView RV;
    private dist_Adapter dAdapter;

    public DistFragment() {
        // Required empty public constructor
    }

    public static DistFragment newInstance(String param1, String param2) {
        DistFragment fragment = new DistFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_dis, container, false);
        final View view = inflater.inflate(R.layout.fragment_dis,container,false);

        RV = view.findViewById(R.id.RV_dis);

        // vertical RecyclerView
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());

        RV.setLayoutManager(mLayoutManager);

        RV.setItemAnimator(new DefaultItemAnimator());

        // adding inbuilt divider line
        RV.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
        RV.setAdapter(dAdapter);


        return view;
    }

}
