package net.sahal.cot_hajj.fragment;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import net.sahal.cot_hajj.Bus_Adapter;
import net.sahal.cot_hajj.Leaved_Adapter;
import net.sahal.cot_hajj.Leaved_Buses;
import net.sahal.cot_hajj.R;

import java.util.ArrayList;
import java.util.List;

public class leavedFragment extends Fragment {

    RecyclerView RV;
    private Leaved_Adapter bAdapter;
    private List<Leaved_Buses> LeavedList = new ArrayList<>();


    public leavedFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_leaved_bus, container, false);


        RV = view.findViewById(R.id.Buses_RV);

        bAdapter = new Leaved_Adapter(LeavedList, getActivity());

        // vertical RecyclerView
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());

        RV.setLayoutManager(mLayoutManager);

        RV.setItemAnimator(new DefaultItemAnimator());

        // adding inbuilt divider line
        RV.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
        RV.setAdapter(bAdapter);

        return view;
    }
}
