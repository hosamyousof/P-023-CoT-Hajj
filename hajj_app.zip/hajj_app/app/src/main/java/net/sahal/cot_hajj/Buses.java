package net.sahal.cot_hajj;

public class Buses {

    private String adad;
    private String seaa;


    public Buses(String adad, String seaa) {
        this.adad = adad;
        this.seaa = seaa;
    }

    public String getAdad() {
        return adad;
    }

    public void setAdad(String adad) {
        this.adad = adad;
    }

    public String getSeaa() {
        return seaa;
    }

    public void setSeaa(String seaa) {
        this.seaa = seaa;
    }

}
