package net.sahal.cot_hajj;

public class Leaved_Buses {

    private String bus_number;


    public Leaved_Buses(String bus_number) {
        this.bus_number = bus_number;
    }

    public String getBus_number() {
        return bus_number;
    }

    public void setBus_number(String bus_number) {
        this.bus_number = bus_number;
    }
}
