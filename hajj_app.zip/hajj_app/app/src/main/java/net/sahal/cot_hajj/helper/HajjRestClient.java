package net.sahal.cot_hajj.helper;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

public class HajjRestClient {

    private final static String BASE_URL = "http://cothajj.azurewebsites.net/";

    private static AsyncHttpClient client = new AsyncHttpClient();

    public static void get(String url , RequestParams params , AsyncHttpResponseHandler responseHandler){

        client.get(getAbsoluteURL(url) ,params,responseHandler);
    }

    public static void post(String url , RequestParams params , AsyncHttpResponseHandler responseHandler){

        client.post(getAbsoluteURL(url) ,params,responseHandler);
    }

    private static String getAbsoluteURL (String relativeURL){return BASE_URL+relativeURL;};
}
