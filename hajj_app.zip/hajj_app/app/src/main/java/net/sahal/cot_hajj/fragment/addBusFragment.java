package net.sahal.cot_hajj.fragment;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import android.support.design.widget.FloatingActionButton;

import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import net.sahal.cot_hajj.Bus_Adapter;
import net.sahal.cot_hajj.Buses;
import net.sahal.cot_hajj.Leaved_Adapter;
import net.sahal.cot_hajj.Leaved_Buses;
import net.sahal.cot_hajj.R;
import net.sahal.cot_hajj.helper.HajjRestClient;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class addBusFragment extends Fragment {

    private RecyclerView RV;
    private Bus_Adapter mAdapter;
    private List<Buses> busesList = new ArrayList<>();
    FloatingActionButton fab;
    Dialog dialog;
    Spinner mspinner;
    EditText add_adad;
    Button reg;


    public addBusFragment() {
        // Required empty public constructor
    }

    public static addBusFragment newInstance(String param1, String param2) {
        addBusFragment fragment = new addBusFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_add_bus, container, false);
        final View view = inflater.inflate(R.layout.fragment_add_bus, container, false);

        RV = view.findViewById(R.id.RV);
        fab = view.findViewById(R.id.fab);
        dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.dialog_add_bus);
        add_adad = dialog.findViewById(R.id.adad_num);
        mspinner = dialog.findViewById(R.id.seaa_n);
        reg = dialog.findViewById(R.id.add_bus_btn);


        RequestParams params = new RequestParams();


            String[] list = {"40", "49"};

        // Initializing an ArrayAdapter
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getContext(), R.layout.spinner_item, list
        );
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item);
        mspinner.setAdapter(spinnerArrayAdapter);


        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.seaa_bus, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        mspinner.setAdapter(adapter);


        mAdapter = new Bus_Adapter(busesList, getContext());

        // vertical RecyclerView
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());

        RV.setLayoutManager(mLayoutManager);

        RV.setItemAnimator(new DefaultItemAnimator());

        // adding inbuilt divider line
        RV.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
        RV.setAdapter(mAdapter);



            fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.show();
            }
        });

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.hide();
            }
        });

            return view;

    }
}

