package net.sahal.cot_hajj;

public class dist_model {

    private String bus_num;

    public dist_model(String bus_num) {
        this.bus_num = bus_num;
    }

    public String getBus_num() {
        return bus_num;
    }

    public void setBus_num(String bus_num) {
        this.bus_num = bus_num;
    }
}
