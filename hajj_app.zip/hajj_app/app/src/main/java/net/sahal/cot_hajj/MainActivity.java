package net.sahal.cot_hajj;

import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import net.sahal.cot_hajj.fragment.DistFragment;
import net.sahal.cot_hajj.fragment.LeaveFragment;
import net.sahal.cot_hajj.fragment.MainFragment;
import net.sahal.cot_hajj.fragment.addBusFragment;
import net.sahal.cot_hajj.fragment.reportFragment;
import net.sahal.cot_hajj.helper.BottomNavigationBehavior;


public class MainActivity extends AppCompatActivity {

    private ActionBar toolbar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = getSupportActionBar();

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        // attaching bottom sheet behaviour - hide / show on scroll
        CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) navigation.getLayoutParams();
        layoutParams.setBehavior(new BottomNavigationBehavior());


        // Create a TextView programmatically.
        TextView tv = new TextView(getApplicationContext());

        // Set text to display in TextView
        tv.setText(toolbar.getTitle());

        // Set the text color of TextView
        tv.setTextColor(Color.WHITE);

        // Set TextView text alignment to center
        tv.setGravity(Gravity.RIGHT);

        // Set the ActionBar display option
        toolbar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        toolbar.setCustomView(tv);


    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.navigation_report:
                    toolbar.setTitle("تبليغ عن باص");
                    fragment = new reportFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_leave:
                    toolbar.setTitle("ترحيل باص");
                    fragment = new LeaveFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_dis:
                    toolbar.setTitle("توزيع الحجاج");
                    fragment = new DistFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_add:
                    toolbar.setTitle("طلب باص");
                    fragment = new addBusFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_main:
                    toolbar.setTitle("الرئيسية");
                    fragment = new MainFragment();
                    loadFragment(fragment);
                    return true;
            }

            return false;
        }
    };

    /**
     * loading fragment into FrameLayout
     *
     * @param fragment
     */
    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
