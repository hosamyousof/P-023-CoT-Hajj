package net.sahal.cot_hajj;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

import net.sahal.cot_hajj.fragment.DistFragment;
import net.sahal.cot_hajj.fragment.LeaveFragment;
import net.sahal.cot_hajj.fragment.MainFragment;
import net.sahal.cot_hajj.fragment.addBusFragment;
import net.sahal.cot_hajj.fragment.reportFragment;
import net.sahal.cot_hajj.helper.BottomNavigationBehavior;

public class MainActivity extends AppCompatActivity {

    private ActionBar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = getSupportActionBar();

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        // attaching bottom sheet behaviour - hide / show on scroll
        CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) navigation.getLayoutParams();
        layoutParams.setBehavior(new BottomNavigationBehavior());

        // load the Main fragment by default
        toolbar.setTitle("Main");
        loadFragment(new MainFragment());




    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.navigation_report:
                    toolbar.setTitle("Report");
                    fragment = new reportFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_leave:
                    toolbar.setTitle("leave");
                    fragment = new LeaveFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_dis:
                    toolbar.setTitle("dis");
                    fragment = new DistFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_add:
                    toolbar.setTitle("Add Bus");
                    fragment = new addBusFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_main:
                    toolbar.setTitle("Main");
                    fragment = new MainFragment();
                    loadFragment(fragment);
                    return true;
            }

            return false;
        }
    };

    /**
     * loading fragment into FrameLayout
     *
     * @param fragment
     */
    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
