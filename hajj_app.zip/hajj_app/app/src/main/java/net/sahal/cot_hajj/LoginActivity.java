package net.sahal.cot_hajj;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import net.sahal.cot_hajj.helper.HajjRestClient;

import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;


public class LoginActivity extends AppCompatActivity {

    TextView signin,user,pass;
    EditText username, password;
    Button sign;
    String userString,passwordString;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        signin = findViewById(R.id.signin_text);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        user = findViewById(R.id.username_text);
        pass = findViewById(R.id.password_text);
        sign = findViewById(R.id.signin);




        final Typeface type = Typeface.createFromAsset(getAssets(),"fonts/JF_Flat_regular.ttf");

        signin.setTypeface(type);
        signin.setTypeface(signin.getTypeface(), Typeface.BOLD);
        username.setTypeface(type);
        password.setTypeface(type);
        user.setTypeface(type);
        pass.setTypeface(type);
        sign.setTypeface(type);


//        Retrofit retrofit = new Retrofit.Builder()
//                .baseUrl("http://cothajj.azurewebsites.net")
//                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
//                .build();


        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //login onClickListener
                userString = username.getText().toString();
                passwordString = password.getText().toString();

                if(TextUtils.isEmpty(userString) || TextUtils.isEmpty(passwordString)){
                    Toast.makeText(LoginActivity.this,"فضلا قم بإدخال اسم المستخدم و كلمة المرور", Toast.LENGTH_LONG).show();

                    return;
                }

                RequestParams params = new RequestParams();

                // maybe no need to params here cuz of the asp.net
                params.put("Email", userString);
                params.put("Password", passwordString);

              //  Toast.makeText(LoginActivity.this ,"api/User/LogIn?Email="+userString+"&Password="+passwordString , Toast.LENGTH_SHORT ).show();
                 HajjRestClient.get("api/User/LogIn?Email="+userString+"&Password="+passwordString, params, new AsyncHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                        try{
                            String res = new String( responseBody ,"UTF-8");

                            JSONObject resObj = new JSONObject(res);

                            if(resObj.getString("IsAuthenticated")== "true"){
                                Toast.makeText(LoginActivity.this , " Login Success" , Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(i);
                            }

                        }
                        catch (Exception ex){
                            //Toast to catch

                            Toast.makeText(LoginActivity.this , " Login Exception" , Toast.LENGTH_SHORT).show();

                        }

                    }

                    @Override
                    public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {


                        Toast.makeText(LoginActivity.this , " Login Failure" , Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });


    }
}
