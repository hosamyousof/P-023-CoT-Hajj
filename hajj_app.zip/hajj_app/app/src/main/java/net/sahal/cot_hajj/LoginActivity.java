package net.sahal.cot_hajj;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    TextView signin,user,pass;
    EditText username, password;
    Button sign;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        signin = findViewById(R.id.signin_text);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        user = findViewById(R.id.username_text);
        pass = findViewById(R.id.password_text);
        sign = findViewById(R.id.signin);


        Typeface type = Typeface.createFromAsset(getAssets(),"fonts/JF_Flat_regular.ttf");

        signin.setTypeface(type);
        signin.setTypeface(signin.getTypeface(), Typeface.BOLD);
        username.setTypeface(type);
        password.setTypeface(type);
        user.setTypeface(type);
        pass.setTypeface(type);
        sign.setTypeface(type);



    }
}
