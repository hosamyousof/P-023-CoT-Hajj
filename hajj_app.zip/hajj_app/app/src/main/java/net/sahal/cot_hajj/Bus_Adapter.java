package net.sahal.cot_hajj;


import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.List;

public class Bus_Adapter extends RecyclerView.Adapter<Bus_Adapter.MyViewHolder>{

    private List<Buses> busList;
    private Context context;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView adad, seaa;

        Typeface type = Typeface.createFromAsset(itemView.getContext().getAssets(),"fonts/JF_Flat_regular.ttf");



        public MyViewHolder(View view) {
            super(view);

            adad = view.findViewById(R.id.adad);
            adad.setTypeface(type);

            seaa = view.findViewById(R.id.seaa);
            seaa.setTypeface(type);

        }

    }

    public Bus_Adapter(List<Buses> uniList, Context context) {
        this.busList = uniList;
        this.context = context;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.add_bus_row, parent, false);


        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final Buses bus = busList.get(position);

        holder.adad.setText(bus.getAdad());
        holder.seaa.setText(bus.getSeaa());

    }


    @Override
    public int getItemCount() {
        return busList.size();
    }

}