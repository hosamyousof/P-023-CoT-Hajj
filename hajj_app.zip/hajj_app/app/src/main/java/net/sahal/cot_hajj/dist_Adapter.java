package net.sahal.cot_hajj;

import android.content.Context;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;


public class dist_Adapter extends RecyclerView.Adapter<dist_Adapter.MyViewHolder>{

    private List<dist_model> disList;
    private Context context;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView bus_num;

        Typeface type = Typeface.createFromAsset(itemView.getContext().getAssets(),"fonts/JF_Flat_regular.ttf");

        public MyViewHolder(View view) {
            super(view);

            bus_num = view.findViewById(R.id.adad);
            bus_num.setTypeface(type);
        }
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final dist_model dis = disList.get(position);

        holder.bus_num.setText(dis.getBus_num());
    }


    @Override
    public int getItemCount() {
        return disList.size();
    }

}
