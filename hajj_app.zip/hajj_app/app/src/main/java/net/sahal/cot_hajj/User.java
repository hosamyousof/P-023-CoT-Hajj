package net.sahal.cot_hajj;

public class User {

        public int success;
        public boolean IsAuthenticated;
        public User User;
        //----------------------//
        public int UserId ;
        public String FullName ;
        public String MobileNo ;
        public String Email ;
        public int OrganizationId ;
        public String OrganizationName ;
        public int OrgTypeId ;
        public String OrgTypeName ;

    public User(int success, boolean isAuthenticated, net.sahal.cot_hajj.User user, int userId, String fullName, String mobileNo, String email, int organizationId, String organizationName, int orgTypeId, String orgTypeName) {
        this.success = success;
        IsAuthenticated = isAuthenticated;
        User = user;
        UserId = userId;
        FullName = fullName;
        MobileNo = mobileNo;
        Email = email;
        OrganizationId = organizationId;
        OrganizationName = organizationName;
        OrgTypeId = orgTypeId;
        OrgTypeName = orgTypeName;
    }


    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public boolean isAuthenticated() {
        return IsAuthenticated;
    }

    public void setAuthenticated(boolean authenticated) {
        IsAuthenticated = authenticated;
    }

    public net.sahal.cot_hajj.User getUser() {
        return User;
    }

    public void setUser(net.sahal.cot_hajj.User user) {
        User = user;
    }

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String fullName) {
        FullName = fullName;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String mobileNo) {
        MobileNo = mobileNo;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public int getOrganizationId() {
        return OrganizationId;
    }

    public void setOrganizationId(int organizationId) {
        OrganizationId = organizationId;
    }

    public String getOrganizationName() {
        return OrganizationName;
    }

    public void setOrganizationName(String organizationName) {
        OrganizationName = organizationName;
    }

    public int getOrgTypeId() {
        return OrgTypeId;
    }

    public void setOrgTypeId(int orgTypeId) {
        OrgTypeId = orgTypeId;
    }

    public String getOrgTypeName() {
        return OrgTypeName;
    }

    public void setOrgTypeName(String orgTypeName) {
        OrgTypeName = orgTypeName;
    }
}
