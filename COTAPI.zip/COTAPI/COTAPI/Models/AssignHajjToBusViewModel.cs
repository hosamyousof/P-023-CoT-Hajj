﻿using System.Collections.Generic;

namespace COTAPI.Models
{
    public class AssignHajjToBusViewModel
    {
        public int BusId { get; set; }
        public List<int> HajjIds { get; set; }
        public int CreatedByUserId { get; set; }
    }
}