﻿using System.Collections.Generic;

namespace COTAPI.Models
{
    public class RequestViewModel
    {
        public int UserId { get;  set; }
        public int RequestTypeId { get;  set; }
        public List<RequestBusDetail> RequestBusDetails { get;  set; }
    }
}