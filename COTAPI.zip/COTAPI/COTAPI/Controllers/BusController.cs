﻿using COTAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Z.EntityFramework.Plus;

namespace COTAPI.Controllers
{
    public class BusController : ApiController
    {
        [HttpGet]
        public IHttpActionResult GetBusesIds(int UserId)
        {
            try
            {

                using (cotdbEntities db = new cotdbEntities())
                {
                    var user = db.User.FirstOrDefault(e => e.UserId == UserId && !e.IsDeleted);

                    if (user != null)
                    {
                        var BusesIdsList = db.Bus.Where(e => e.OrganizationId == user.OrganizationId).Select(e =>
                        new
                        {
                            e.BusId,
                            e.BusGPSId,
                            e.PlateNo,
                            e.Capacity,
                            e.ModelDetails,
                            e.DriverFullName,
                        }).ToList();
                        return Json(new { success = 1, BusesIdsList });
                    }
                    else
                    {
                        return Json(new { success = 1 });
                    }




                }

            }
            catch (Exception ex)
            {
                // log the exception 
                return Json(new { success = 0, ex.Message });
            }
        }


        [HttpGet]
        public IHttpActionResult GetBusAssignedHajjIds(int BusId)
        {
            try
            {

                using (cotdbEntities db = new cotdbEntities())
                {
                    var HajjIdsList = db.HajjBus.Where(e => e.BusId == BusId && e.IsActive).Select(e =>
                    new
                    {
                        e.Hajj.FirstName,
                        e.Hajj.SecondName,
                        e.Hajj.MiddleName,
                        e.Hajj.SurName,
                        e.CreateDate,
                    }).ToList();



                    return Json(new { success = 1, BusId, HajjIdsList });
                }

            }
            catch (Exception ex)
            {
                // log the exception 
                return Json(new { success = 0, ex.Message });
            }
        }


        [HttpPost]
        public IHttpActionResult AssignHajjToBus([FromBody] AssignHajjToBusViewModel obj)
        {
            try
            {

                using (cotdbEntities db = new cotdbEntities())
                {
                    db.HajjBus.Where(e => e.BusId == obj.BusId && e.IsActive).Update(e => new HajjBus { IsActive = false });

                    var list = obj.HajjIds.Select(HajjId => new HajjBus
                    {
                        BusId = obj.BusId,
                        HajjId = HajjId,
                        CreatedByUserId = obj.CreatedByUserId,
                        CreateDate = DateTime.UtcNow,
                        IsActive = true,
                    }).ToList();

                    db.HajjBus.AddRange(list);
                    db.SaveChanges();

                    return Json(new { success = 1 });
                }

            }
            catch (Exception ex)
            {
                // log the exception 
                return Json(new { success = 0, ex.Message });
            }
        }


    }
}