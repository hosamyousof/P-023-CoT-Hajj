﻿using COTAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Z.EntityFramework.Plus;

namespace COTAPI.Controllers
{
    public enum RequestTypeIds
    {
        RequestBus = 1,
        Notice = 2
    }
    public enum RequestStatusIds
    {
        New = 1,
        UnderProcessing = 2,
        Rejected = 3,
        Approved = 4,
    };


    public class UserController : ApiController
    {

        [HttpGet]
        public IHttpActionResult LogIn(string Email, string Password)
        {
            try
            {
                using (cotdbEntities db = new cotdbEntities())
                {
                    var user = db.User.FirstOrDefault(e => e.Email == Email && !e.IsDeleted);


                    if (user != null && user.Password == Password)
                    {
                        return Json(new
                        {
                            success = 1,
                            IsAuthenticated = true,
                            User = new
                            {
                                user.UserId,
                                user.FullName,
                                user.MobileNo,
                                user.Email,
                                user.OrganizationId,
                                OrganizationName = user.Organization.Name,
                                user.Organization.OrgTypeId,
                                OrgTypeName = user.Organization.LK_OrgType.Name
                            }
                        });
                    }
                    else
                    {
                        return Json(new { success = 1, IsAuthenticated = false });
                    }
                }
            }
            catch (Exception ex)
            {
                // log the exception 
                return Json(new { success = 0, IsAuthenticated = false, ex.Message });
            }

        }


        [HttpGet]
        public IHttpActionResult GetUserById(int UserId)
        {
            try
            {
                using (cotdbEntities db = new cotdbEntities())
                {
                    var user = db.User.FirstOrDefault(e => e.UserId == UserId && !e.IsDeleted);


                    if (user != null)
                    {
                        return Json(new
                        {
                            success = 1,
                            IsAuthenticated = true,
                            User = new
                            {
                                user.UserId,
                                user.FullName,
                                user.MobileNo,
                                user.Email,
                                user.OrganizationId,
                                OrganizationName = user.Organization.Name,
                                user.Organization.OrgTypeId,
                                OrgTypeName = user.Organization.LK_OrgType.Name
                            }
                        });
                    }
                    else
                    {
                        return Json(new { success = 2, Message = "User not fount with the given UserId" });
                    }
                }
            }
            catch (Exception ex)
            {
                // log the exception 
                return Json(new { success = 0, ex.Message });
            }

        }

    }
}