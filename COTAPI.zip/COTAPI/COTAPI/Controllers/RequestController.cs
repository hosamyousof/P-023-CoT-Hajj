﻿using COTAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace COTAPI.Controllers
{
    public class RequestController : ApiController
    {
        /// <summary>
        /// RequestTypeId: 1 for "RequestBus", 2 for "Notice"
        /// </summary>
        [HttpPost]
        public IHttpActionResult AddRequest([FromBody] RequestViewModel req)
        {
            try
            {
                using (cotdbEntities db = new cotdbEntities())
                {
                    var request = new Request
                    {
                        UserId = req.UserId,
                        RequestStatusId = (int)RequestStatusIds.New,
                        TypeId = req.RequestTypeId,
                        CreateDate = DateTime.UtcNow,
                        IsDeleted = false,
                    };

                    if (req.RequestTypeId == (int)RequestTypeIds.RequestBus)
                    {
                        request.RequestDetails = req.RequestBusDetails.Select(e => new RequestDetails
                        {
                            Capacity = e.Capacity,
                            Quantity = e.Quantity,
                            Note = e.Note
                        }).ToList();
                    }

                    db.Request.Add(request);
                    db.SaveChanges();
                    return Json(new { success = 1 });
                }
            }
            catch (Exception ex)
            {
                // log the exception 
                return Json(new { success = 0, ex.Message });
            }

        }
        
        [HttpGet]
        public IHttpActionResult GetRequests(int UserId)
        {
            try
            {
                using (cotdbEntities db = new cotdbEntities())
                {
                    var user = db.User.FirstOrDefault(e => e.UserId == UserId && !e.IsDeleted);
                    
                    if (user != null)
                    {
                        var RequestsList = db.Request.Where(e => e.TypeId == 1 && e.User.OrganizationId == user.OrganizationId && !e.IsDeleted).Select(e =>
                          new
                          {
                              e.UserId,
                              UserFullName = e.User.FullName,
                              e.CreateDate,
                              RequestDetails = e.RequestDetails.Select(d=>new {
                                  d.Capacity,
                                  d.Quantity,
                                  d.Note,
                              }).ToList(),
                              RequestActionsDetails = e.RequestActionsDetails.Select(r => new
                              {
                                  r.Id,
                                  r.UserId,
                                  UserFullName = r.User.FullName,
                                  r.ActionId,
                                  ActionName = r.LK_Action.Name,
                                  r.Note,
                                  r.ActionDate
                              }).ToList(),
                          }).ToList();

                        return Json(new { success = 1 , RequestsList });
                    }
                    else
                    {
                        return Json(new { success = 2 });
                    }
                }
            }
            catch (Exception ex)
            {
                // log the exception 
                return Json(new
                {
                    success = 0,
                    ex.Message
                });
            }

        }

        [HttpGet]
        public IHttpActionResult GetNotices(int UserId)
        {
            try
            {
                using (cotdbEntities db = new cotdbEntities())
                {
                    var user = db.User.FirstOrDefault(e => e.UserId == UserId && !e.IsDeleted);

                    if (user != null)
                    {
                        var RequestsList = db.Request.Where(e => e.TypeId == 2 && e.User.OrganizationId == user.OrganizationId && !e.IsDeleted).Select(e =>
                          new
                          {
                              e.UserId,
                              UserFullName = e.User.FullName,
                              e.CreateDate,
                              RequestDetails = e.RequestActionsDetails.Select(r => new
                              {
                                  r.Id,
                                  r.UserId,
                                  UserFullName = r.User.FullName,
                                  r.ActionId,
                                  ActionName = r.LK_Action.Name,
                                  r.Note,
                                  r.ActionDate
                              }).ToList(),
                          }).ToList();

                        return Json(new { success = 1, RequestsList });
                    }
                    else
                    {
                        return Json(new { success = 2 , Message="User not fount with the given UserId"});
                    }
                }
            }
            catch (Exception ex)
            {
                // log the exception 
                return Json(new
                {
                    success = 0,
                    ex.Message
                });
            }

        }


    }
}